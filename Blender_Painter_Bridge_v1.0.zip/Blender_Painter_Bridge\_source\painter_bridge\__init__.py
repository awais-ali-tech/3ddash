bl_info = {
    "name": "Painter Bridge",
    "author": "Smiley Pixel Studio",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar (N) > Painter",
    "description": "One click: send meshes to Substance 3D Painter and get textures back",
    "category": "Import-Export",
}

import json
import os
import subprocess
import time
import glob
import re

import bpy

PAINTER_EXE_NAME = "Adobe Substance 3D Painter.exe"


def _find_painter():
    """Best guess for the Painter .exe (standard Adobe install, then Steam)."""
    roots = [os.environ.get("ProgramFiles", r"C:\Program Files"),
             os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    cands = []
    for r in roots:
        cands.append(os.path.join(r, "Adobe", "Adobe Substance 3D Painter", PAINTER_EXE_NAME))
        cands += glob.glob(os.path.join(r, "Adobe", "Adobe Substance 3D Painter*", PAINTER_EXE_NAME))
        cands += glob.glob(os.path.join(r, "Steam", "steamapps", "common", "Substance 3D Painter*", PAINTER_EXE_NAME))
    for c in cands:
        if os.path.isfile(c):
            return c
    return cands[0]


DEFAULT_PAINTER = _find_painter()
# Must be the same folder the Painter plugin watches: Documents/BlenderPainterBridge,
# or the BLENDER_PAINTER_BRIDGE environment variable if it is set.
DEFAULT_BRIDGE = os.environ.get("BLENDER_PAINTER_BRIDGE") or \
    os.path.join(os.path.expanduser("~"), "Documents", "BlenderPainterBridge")
MAPS = ("BaseColor", "Roughness", "Metallic", "Normal")


def prefs():
    return bpy.context.preferences.addons[__name__].preferences


def read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def write_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def painter_running():
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Adobe Substance 3D Painter.exe"],
                             capture_output=True, text=True, creationflags=0x08000000).stdout
        return "Adobe Substance 3D Painter.exe" in out
    except Exception:
        return False


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", s).strip("_") or "Untitled"


def job_objects(context):
    names = context.scene.get("pb_objects")
    if names:
        objs = [bpy.data.objects.get(n) for n in names]
        objs = [o for o in objs if o]
        if objs:
            return objs
    return [o for o in context.selected_objects if o.type == 'MESH']


# --------------------------------------------------------------------------- #
class PB_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    painter_exe: bpy.props.StringProperty(name="Painter .exe", subtype='FILE_PATH', default=DEFAULT_PAINTER)
    bridge_dir: bpy.props.StringProperty(
        name="Bridge folder", subtype='DIR_PATH', default=DEFAULT_BRIDGE,
        description="Folder shared with the Painter plugin. Keep the default unless you also "
                    "set the BLENDER_PAINTER_BRIDGE environment variable")
    resolution: bpy.props.EnumProperty(
        name="Painter working size",
        items=[("1024", "1K", ""), ("2048", "2K", ""), ("4096", "4K", "")], default="2048")
    export_size: bpy.props.EnumProperty(
        name="Texture size back",
        items=[("512", "512", ""), ("1024", "1K", ""), ("2048", "2K", ""), ("4096", "4K", "")], default="1024")
    auto_import: bpy.props.BoolProperty(name="Auto-load textures when Painter sends them", default=True)
    send_textures: bpy.props.BoolProperty(
        name="Send current textures as a starting layer",
        description="On a new Painter project, put the material's current images in a fill layer",
        default=True)

    def draw(self, context):
        c = self.layout.column()
        for p in ("painter_exe", "bridge_dir", "resolution", "export_size", "auto_import", "send_textures"):
            c.prop(self, p)


def _linked_image(bsdf, socket):
    """Image feeding a BSDF input (through an optional Normal Map node)."""
    inp = bsdf.inputs.get(socket)
    if not inp or not inp.is_linked:
        return None
    n = inp.links[0].from_node
    if n.type == 'NORMAL_MAP':
        c = n.inputs.get("Color")
        if not c or not c.is_linked:
            return None
        n = c.links[0].from_node
    return n.image if n.type == 'TEX_IMAGE' and n.image else None


def collect_textures(objs, job_dir):
    """Save the images currently on the material(s) so Painter can start from them.
    Returns {texture_set_name: {map: path}}."""
    out = {}
    src_dir = os.path.join(job_dir, "from_blender")
    os.makedirs(src_dir, exist_ok=True)
    for o in objs:
        for s in o.material_slots:
            m = s.material
            if not m or not m.node_tree or m.name in out:
                continue
            bsdf = next((n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if not bsdf:
                continue
            maps = {}
            for key, sock in (("BaseColor", "Base Color"), ("Roughness", "Roughness"),
                              ("Metallic", "Metallic"), ("Normal", "Normal")):
                img = _linked_image(bsdf, sock)
                if img is None or img.size[0] == 0:
                    continue
                path = os.path.join(src_dir, "%s_%s.png" % (safe_name(m.name), key))
                tmp = img.copy()
                try:
                    tmp.filepath_raw = path
                    tmp.file_format = 'PNG'
                    tmp.save()
                    maps[key] = path
                except Exception as ex:
                    print("[Painter Bridge] could not save", img.name, ex)
                finally:
                    bpy.data.images.remove(tmp)
            if maps:
                out[m.name] = maps
    return out


# --------------------------------------------------------------------------- #
class PB_OT_send(bpy.types.Operator):
    bl_idname = "painter_bridge.send"
    bl_label = "Send to Painter"
    bl_description = "Export the selected meshes to Substance 3D Painter (opens Painter if needed)"

    fresh: bpy.props.BoolProperty(
        name="New Painter project",
        description="Start a new Painter project (old one is kept as a backup) instead of updating the mesh",
        default=False)
    auto_return: bpy.props.BoolProperty(
        name="Send textures straight back",
        description="Painter exports the textures back to Blender as soon as the project is ready",
        default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        p = prefs()
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            objs = [o for o in context.visible_objects if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "Select the mesh(es) to send")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        stem = os.path.splitext(os.path.basename(bpy.data.filepath))[0] if bpy.data.filepath else "Untitled"
        name = safe_name(stem)
        root = bpy.path.abspath(p.bridge_dir) or DEFAULT_BRIDGE
        job_dir = os.path.join(root, name)
        tex_dir = os.path.join(job_dir, "textures")
        os.makedirs(tex_dir, exist_ok=True)
        mesh = os.path.join(job_dir, name + ".fbx")

        prev_sel = list(context.selected_objects)
        prev_act = context.view_layer.objects.active
        for o in context.selected_objects:
            o.select_set(False)
        for o in objs:
            o.select_set(True)
        context.view_layer.objects.active = objs[0]
        try:
            bpy.ops.export_scene.fbx(
                filepath=mesh, use_selection=True, object_types={'MESH'},
                use_mesh_modifiers=True, mesh_smooth_type='FACE', use_tspace=True,
                colors_type='NONE', add_leaf_bones=False, bake_anim=False,
                path_mode='AUTO', embed_textures=False)
        finally:
            for o in context.selected_objects:
                o.select_set(False)
            for o in prev_sel:
                if o.name in bpy.data.objects:
                    o.select_set(True)
            context.view_layer.objects.active = prev_act

        layers = {}
        if p.send_textures:
            layers = collect_textures(objs, job_dir)

        job = {
            "layers": layers,
            "fresh": self.fresh,
            "auto_return": self.auto_return,
            "status": "pending",
            "name": name,
            "mesh": mesh,
            "job_dir": job_dir,
            "textures_dir": tex_dir,
            "spp": os.path.join(job_dir, name + ".spp"),
            "blend": bpy.data.filepath,
            "objects": [o.name for o in objs],
            "materials": sorted({s.material.name for o in objs for s in o.material_slots if s.material}),
            "normal": "OpenGL",
            "resolution": int(p.resolution),
            "export_size": int(p.export_size),
            "sent": time.time(),
        }
        os.makedirs(root, exist_ok=True)
        write_json(os.path.join(root, "inbox.json"), job)
        context.scene["pb_job_dir"] = job_dir
        context.scene["pb_objects"] = job["objects"]
        done = os.path.join(tex_dir, "done.json")
        context.scene["pb_last_import"] = os.path.getmtime(done) if os.path.exists(done) else 0.0

        if not painter_running():
            exe = bpy.path.abspath(p.painter_exe)
            if os.path.isfile(exe):
                # Blender sets OCIO to its own config for its process; Painter
                # can't read that config version, so launch it without it.
                env = {k: v for k, v in os.environ.items() if k.upper() != "OCIO"}
                subprocess.Popen([exe], cwd=os.path.dirname(exe), env=env)
                self.report({'INFO'}, "Opening Painter, the mesh loads when it's ready")
            else:
                self.report({'WARNING'}, "Painter not found, set its path in the add-on preferences")
        else:
            self.report({'INFO'}, "Sent %d object(s) to Painter" % len(objs))
        return {'FINISHED'}


def import_textures(context, report=None):
    job_dir = context.scene.get("pb_job_dir")
    if not job_dir:
        return "Nothing sent to Painter from this file yet"
    tex_dir = os.path.join(job_dir, "textures")
    done = read_json(os.path.join(tex_dir, "done.json"))
    if not done:
        return "No textures from Painter yet, press 'Send to Blender' in Painter"

    # texture set name -> {map: path}
    sets = {}
    for f in glob.glob(os.path.join(tex_dir, "*.jpg")) + glob.glob(os.path.join(tex_dir, "*.png")):
        base = os.path.splitext(os.path.basename(f))[0]
        for m in MAPS:
            if base.endswith("_" + m):
                sets.setdefault(base[:-len(m) - 1], {})[m] = f
    if not sets:
        return "No texture files found in %s" % tex_dir

    objs = job_objects(context)
    mats = []
    for o in objs:
        for s in o.material_slots:
            if s.material and s.material not in mats:
                mats.append(s.material)
    if not mats:
        mat = bpy.data.materials.new(safe_name(objs[0].name if objs else "Painter") + "_MAT")
        for o in objs:
            o.data.materials.append(mat)
        mats = [mat]

    used = 0
    for mat in mats:
        tex = sets.get(mat.name) or sets.get(safe_name(mat.name))
        if tex is None and len(sets) == 1 and len(mats) == 1:
            tex = next(iter(sets.values()))
        if tex is None:
            continue
        build_material(mat, tex)
        used += 1
    context.scene["pb_last_import"] = os.path.getmtime(os.path.join(tex_dir, "done.json"))
    if not used:
        return "Texture sets %s don't match materials %s" % (list(sets), [m.name for m in mats])
    return None


def load_image(path, non_color):
    img = None
    for i in bpy.data.images:
        if i.filepath and os.path.normcase(bpy.path.abspath(i.filepath)) == os.path.normcase(path):
            img = i
            break
    if img is None:
        img = bpy.data.images.load(path)
    else:
        img.reload()
    img.colorspace_settings.name = 'Non-Color' if non_color else 'sRGB'
    return img


def build_material(mat, tex):
    if hasattr(mat, "use_nodes") and not mat.use_nodes:
        mat.use_nodes = True
    nt = mat.node_tree
    bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if bsdf is None:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        out = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None) or nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(bsdf.outputs[0], out.inputs[0])
    x, y = bsdf.location.x - 600, bsdf.location.y + 300
    sockets = {"BaseColor": "Base Color", "Roughness": "Roughness", "Metallic": "Metallic"}
    for i, m in enumerate(MAPS):
        if m not in tex:
            continue
        key = "PB_" + m
        node = nt.nodes.get(key)
        if node is None:
            node = nt.nodes.new("ShaderNodeTexImage")
            node.name = node.label = key
            node.location = (x, y - i * 300)
        node.image = load_image(tex[m], non_color=(m != "BaseColor"))
        if m == "Normal":
            nm = nt.nodes.get("PB_NormalMap")
            if nm is None:
                nm = nt.nodes.new("ShaderNodeNormalMap")
                nm.name = nm.label = "PB_NormalMap"
                nm.location = (x + 300, y - i * 300)
            nt.links.new(node.outputs["Color"], nm.inputs["Color"])
            nt.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])
        else:
            nt.links.new(node.outputs["Color"], bsdf.inputs[sockets[m]])


class PB_OT_get(bpy.types.Operator):
    bl_idname = "painter_bridge.get"
    bl_label = "Get Textures"
    bl_description = "Load the textures Painter sent back onto the materials"

    def execute(self, context):
        err = import_textures(context)
        if err:
            self.report({'WARNING'}, err)
            return {'CANCELLED'}
        self.report({'INFO'}, "Textures loaded from Painter")
        return {'FINISHED'}


class PB_OT_open_folder(bpy.types.Operator):
    bl_idname = "painter_bridge.open_folder"
    bl_label = "Open Bridge Folder"

    def execute(self, context):
        d = context.scene.get("pb_job_dir") or bpy.path.abspath(prefs().bridge_dir)
        if os.path.isdir(d):
            os.startfile(d)
        return {'FINISHED'}


class PB_PT_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Painter"
    bl_label = "Painter Bridge"

    def draw(self, context):
        lay = self.layout
        col = lay.column(align=True)
        col.scale_y = 1.4
        col.operator("painter_bridge.send", icon='EXPORT').fresh = False
        col.operator("painter_bridge.send", text="Send as New Project", icon='FILE_NEW').fresh = True
        col.operator("painter_bridge.get", icon='IMPORT')
        lay.operator("painter_bridge.open_folder", icon='FILE_FOLDER')
        p = prefs()
        lay.prop(p, "export_size")
        lay.prop(p, "auto_import", text="Auto-load textures")
        lay.prop(p, "send_textures", text="Send current textures")
        inbox = read_json(os.path.join(bpy.path.abspath(p.bridge_dir) or DEFAULT_BRIDGE, "inbox.json"))
        if inbox and context.scene.get("pb_job_dir") == inbox.get("job_dir"):
            lay.label(text="Painter: %s" % inbox.get("status", "?"))
            if inbox.get("error"):
                lay.label(text=inbox["error"][:60], icon='ERROR')


# --------------------------------------------------------------------------- #
def _watch():
    try:
        ctx = bpy.context
        p = prefs()
        if p.auto_import and ctx.scene and ctx.scene.get("pb_job_dir"):
            done = os.path.join(ctx.scene["pb_job_dir"], "textures", "done.json")
            if os.path.exists(done) and os.path.getmtime(done) > ctx.scene.get("pb_last_import", 0.0) + 0.01:
                time.sleep(0.3)
                err = import_textures(ctx)
                print("[Painter Bridge]", err or "textures loaded")
                for w in ctx.window_manager.windows:
                    for a in w.screen.areas:
                        a.tag_redraw()
    except Exception as ex:
        print("[Painter Bridge] watch error:", ex)
    return 2.0


classes = (PB_Preferences, PB_OT_send, PB_OT_get, PB_OT_open_folder, PB_PT_panel)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    if not bpy.app.timers.is_registered(_watch):
        bpy.app.timers.register(_watch, first_interval=2.0, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_watch):
        bpy.app.timers.unregister(_watch)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
