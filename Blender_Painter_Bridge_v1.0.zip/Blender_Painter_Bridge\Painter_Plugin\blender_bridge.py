"""Blender <-> Substance 3D Painter bridge (Painter side).

Blender's "Send to Painter" button writes a job into
Documents/BlenderPainterBridge/inbox.json. This plugin watches that file,
creates (or updates) the Painter project from the sent FBX, and adds a
"Send to Blender" button that exports BaseColor / Roughness / Metallic /
Normal (OpenGL) JPGs back to the job folder, where Blender picks them up.
"""
import json
import os
import time
import glob

from PySide6 import QtCore, QtWidgets, QtGui

import substance_painter.project as sp_project
import substance_painter.export as sp_export
import substance_painter.textureset as sp_textureset
import substance_painter.ui as sp_ui
import substance_painter.logging as sp_log

BRIDGE_DIR = os.environ.get("BLENDER_PAINTER_BRIDGE") or \
    os.path.join(os.path.expanduser("~"), "Documents", "BlenderPainterBridge")
INBOX = os.path.join(BRIDGE_DIR, "inbox.json")
TAG = "BlenderBridge"

_state = {"timer": None, "widgets": [], "job": None, "busy": False}


def _log(msg):
    sp_log.info("[%s] %s" % (TAG, msg))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _write_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def _set_inbox_status(status, **extra):
    data = _read_json(INBOX) or {}
    data["status"] = status
    data.update(extra)
    _write_json(INBOX, data)


def _norm(p):
    return os.path.normcase(os.path.abspath(p)) if p else ""


# --------------------------------------------------------------------------- #
# Receiving a mesh from Blender
# --------------------------------------------------------------------------- #
def _poll():
    if _state["busy"]:
        return
    job = _read_json(INBOX)
    if not job or job.get("status") != "pending":
        return
    if not os.path.isfile(job.get("mesh", "")):
        _set_inbox_status("error", error="Mesh file not found: %s" % job.get("mesh"))
        return
    try:
        if sp_project.is_open() and sp_project.is_busy():
            return
    except Exception:
        return
    _state["busy"] = True
    try:
        _load_job(job)
    except Exception as ex:  # keep Painter alive whatever happens
        _log("Failed to load job: %s" % ex)
        _set_inbox_status("error", error=str(ex))
        _state["busy"] = False


def _load_job(job):
    spp = job.get("spp")
    mesh = job["mesh"]

    # Same job already open -> just update the mesh, keep the painting.
    if sp_project.is_open():
        current = _norm(sp_project.file_path())
        same = (spp and current == _norm(spp)) or _norm(sp_project.last_imported_mesh_path()) == _norm(mesh)
        if same and not job.get("fresh"):
            _log("Updating mesh of the open project")
            _set_inbox_status("loading")
            settings = sp_project.MeshReloadingSettings(import_cameras=False, preserve_strokes=True)

            def done(status):
                ok = status == sp_project.ReloadMeshStatus.SUCCESS
                _state["job"] = job
                _set_inbox_status("loaded" if ok else "error",
                                  error="" if ok else "Mesh reload failed, see Painter log")
                _state["busy"] = False
            sp_project.reload_mesh(mesh, settings, done)
            return

        answer = QtWidgets.QMessageBox.question(
            sp_ui.get_main_window(), "Blender Bridge",
            "Blender sent '%s'.\n\nClose the current project to open it?\n"
            "(Unsaved changes in the current project will be lost.)" % job.get("name", "mesh"),
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        if answer != QtWidgets.QMessageBox.Yes:
            _set_inbox_status("declined")
            _state["busy"] = False
            return
        sp_project.close()

    # A fresh start keeps the old project as a backup instead of reopening it.
    if job.get("fresh") and spp and os.path.isfile(spp):
        os.replace(spp, os.path.splitext(spp)[0] + "_old_%d.spp" % int(time.time()))

    # Re-open an existing Painter project for this job if we saved one before.
    if spp and os.path.isfile(spp):
        _log("Opening saved project %s" % spp)
        _set_inbox_status("loading")
        sp_project.open(spp)

        def after_open():
            settings = sp_project.MeshReloadingSettings(import_cameras=False, preserve_strokes=True)

            def done(status):
                _state["job"] = job
                _set_inbox_status("loaded")
                _state["busy"] = False
            sp_project.reload_mesh(mesh, settings, done)
        sp_project.execute_when_not_busy(after_open)
        return

    _log("Creating project from %s" % mesh)
    _set_inbox_status("loading")
    fmt = sp_project.NormalMapFormat.OpenGL if job.get("normal", "OpenGL") == "OpenGL" \
        else sp_project.NormalMapFormat.DirectX
    settings = sp_project.Settings(
        normal_map_format=fmt,
        tangent_space_mode=sp_project.TangentSpace.PerFragment,
        default_texture_resolution=int(job.get("resolution", 2048)),
        import_cameras=False,
        export_path=job.get("textures_dir"))
    sp_project.create(mesh_file_path=mesh, settings=settings)

    def after_create():
        try:
            _add_start_layers(job)
        except Exception as ex:
            _log("Could not add the Blender textures layer: %s" % ex)
        try:
            if spp:
                os.makedirs(os.path.dirname(spp), exist_ok=True)
                sp_project.save_as(spp)
        except Exception as ex:
            _log("Could not save project: %s" % ex)
        _state["job"] = job
        _set_inbox_status("loaded")
        _state["busy"] = False
        if job.get("auto_return"):
            QtCore.QTimer.singleShot(4000, lambda: sp_project.execute_when_not_busy(_auto_return))
    sp_project.execute_when_not_busy(after_create)


def _auto_return():
    try:
        send_to_blender(quiet=True)
        _set_inbox_status("returned")
    except Exception as ex:
        _log("Auto return failed: %s" % ex)
        _set_inbox_status("error", error="Auto return failed: %s" % ex)


def _add_start_layers(job):
    """Put the textures Blender sent into a fill layer per texture set."""
    layers = job.get("layers") or {}
    if not layers:
        return
    import substance_painter.layerstack as ls
    import substance_painter.resource as res
    import substance_painter.colormanagement as cm
    CT = sp_textureset.ChannelType
    chan = {"BaseColor": CT.BaseColor, "Roughness": CT.Roughness,
            "Metallic": CT.Metallic, "Normal": CT.Normal}
    sets = {ts.name(): ts for ts in sp_textureset.all_texture_sets()}
    for set_name, maps in layers.items():
        ts = sets.get(set_name)
        if ts is None and len(sets) == 1 and len(layers) == 1:
            ts = next(iter(sets.values()))
        if ts is None:
            _log("No texture set named %s" % set_name)
            continue
        stack = ts.get_stack()
        with ls.ScopedModification("Blender textures"):
            fill = ls.insert_fill(ls.InsertPosition.from_textureset_stack(stack))
            fill.set_name("From Blender (original texture)")
            active = {chan[k] for k in maps if k in chan}
            # Defaults so the layer doesn't come in shiny/metal
            if "Roughness" not in maps:
                active.add(CT.Roughness)
            if "Metallic" not in maps:
                active.add(CT.Metallic)
            fill.active_channels = active
            for key, path in maps.items():
                if key not in chan or not os.path.isfile(path):
                    continue
                r = res.import_project_resource(path, res.Usage.TEXTURE)
                fill.set_source(chan[key], r.identifier())
            if "Roughness" not in maps:
                fill.set_source(CT.Roughness, cm.Color(0.8, 0.8, 0.8))
            if "Metallic" not in maps:
                fill.set_source(CT.Metallic, cm.Color(0.0, 0.0, 0.0))
        _log("Added Blender textures to %s" % ts.name())


# --------------------------------------------------------------------------- #
# Sending textures back to Blender
# --------------------------------------------------------------------------- #
def _export_preset(size_log2):
    def rgb(src_type, name):
        return [{"destChannel": c, "srcChannel": c, "srcMapType": src_type, "srcMapName": name}
                for c in "RGB"]

    def lum(name):
        return [{"destChannel": "L", "srcChannel": "L", "srcMapType": "documentMap", "srcMapName": name}]
    params = {"fileFormat": "jpeg", "bitDepth": "8", "dithering": True,
              "sizeLog2": size_log2, "paddingAlgorithm": "infinite"}
    return {
        "name": "BlenderBridge",
        "maps": [
            {"fileName": "$textureSet_BaseColor", "channels": rgb("documentMap", "basecolor"), "parameters": params},
            {"fileName": "$textureSet_Roughness", "channels": lum("roughness"), "parameters": params},
            {"fileName": "$textureSet_Metallic", "channels": lum("metallic"), "parameters": params},
            {"fileName": "$textureSet_Normal", "channels": rgb("virtualMap", "Normal_OpenGL"), "parameters": params},
        ]}


def send_to_blender(quiet=False):
    if not sp_project.is_open():
        QtWidgets.QMessageBox.warning(sp_ui.get_main_window(), "Blender Bridge", "No project is open.")
        return
    job = _state["job"] or _read_json(INBOX)
    if not job or not job.get("textures_dir"):
        QtWidgets.QMessageBox.warning(sp_ui.get_main_window(), "Blender Bridge",
                                      "This project didn't come from Blender.\n"
                                      "Use 'Send to Painter' in Blender first.")
        return
    out = job["textures_dir"]
    os.makedirs(out, exist_ok=True)
    size = int(job.get("export_size", 1024))
    size_log2 = max(7, min(13, size.bit_length() - 1))
    sets = [ts.name() for ts in sp_textureset.all_texture_sets()]
    config = {
        "exportShaderParams": False,
        "exportPath": out,
        "defaultExportPreset": "BlenderBridge",
        "exportPresets": [_export_preset(size_log2)],
        "exportList": [{"rootPath": s} for s in sets],
    }
    res = sp_export.export_project_textures(config)
    if res.status != sp_export.ExportStatus.Success:
        if quiet:
            raise RuntimeError(res.message)
        QtWidgets.QMessageBox.warning(sp_ui.get_main_window(), "Blender Bridge",
                                      "Export failed: %s" % res.message)
        return
    files = []
    for lst in res.textures.values():
        for f in lst:
            root, ext = os.path.splitext(f)
            if ext.lower() == ".jpeg":  # brief wants .jpg
                new = root + ".jpg"
                os.replace(f, new)
                f = new
            files.append(f)
    _write_json(os.path.join(out, "done.json"),
                {"time": time.time(), "texture_sets": sets, "files": files, "normal": "OpenGL"})
    try:
        if sp_project.file_path():
            sp_project.save()
        elif job.get("spp"):
            sp_project.save_as(job["spp"])
    except Exception as ex:
        _log("Could not save project: %s" % ex)
    _log("Sent %d textures to Blender" % len(files))
    try:
        sp_ui.get_main_window().statusBar().showMessage(
            "Blender Bridge: sent %d textures to Blender" % len(files), 6000)
    except Exception:
        pass


# --------------------------------------------------------------------------- #
def start_plugin():
    os.makedirs(BRIDGE_DIR, exist_ok=True)
    btn = QtWidgets.QToolButton()
    btn.setText("Send to Blender")
    btn.setToolTip("Export BaseColor/Roughness/Metallic/Normal (OpenGL) JPGs to Blender")
    btn.clicked.connect(send_to_blender)
    sp_ui.add_plugins_toolbar_widget(btn)
    _state["widgets"].append(btn)

    act = QtGui.QAction("Send to Blender", sp_ui.get_main_window())
    act.setShortcut(QtGui.QKeySequence("Ctrl+Shift+B"))
    act.triggered.connect(send_to_blender)
    sp_ui.add_action(sp_ui.ApplicationMenu.File, act)
    _state["widgets"].append(act)

    t = QtCore.QTimer()
    t.setInterval(1500)
    t.timeout.connect(_poll)
    t.start()
    _state["timer"] = t
    _log("Ready, watching %s" % INBOX)


def close_plugin():
    if _state["timer"]:
        _state["timer"].stop()
        _state["timer"] = None
    for w in _state["widgets"]:
        try:
            sp_ui.delete_ui_element(w)
        except Exception:
            pass
    _state["widgets"].clear()


if __name__ == "__main__":
    start_plugin()
